package guru.sfg.beer.order.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BeerOrderServiceApplicationTests {

    @Test
    public void contextLoads() {
    }

}
