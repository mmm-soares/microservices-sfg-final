package guru.springframework.msscbeerservice;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MsscBeerServiceApplicationTests {

    @Test
    public void contextLoads() {
    }

}
