package guru.springframework.msscbeerservice.web.controller;

/**
 * Created by jt on 2019-06-06.
 */
public class NotFoundException extends RuntimeException {
}
